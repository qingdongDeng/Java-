import java.util.Scanner;
import com.dqd.book.show;
import com.dqd.book.solve;

public class main {
	public static void main(String[] args) {
		Scanner cin = new Scanner(System.in);
		show s =new show();
		s.lay();
	}
}
