package com.dqd.book;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class solve {
	Scanner cin = new Scanner(System.in);
	String id="";
	String name = "";
	static List list = new ArrayList<book>();
	
	show s =new show();
	
	public void add(){
		System.out.println("�������û���id��name:");
		id = cin.next();name = cin.next();
		book b = new book(id,name);
		solve.list.add(b);
		System.out.println(solve.list.size());
		s.lay();
	}
	public void select(){
		boolean vis = false;
		System.out.println("��������Ҫ�鿴�ı��");
		int tmp=-1;
		tmp = cin.nextInt();
		for(int i = 0;i<solve.list.size();++ i){
			book t = (book)solve.list.get(i);
			try{
				if(  Integer.valueOf(t.getId())==tmp ){
					vis = true;
					System.out.println(t.getId()+"  "+t.getName());
					break;
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		if(!vis){
			System.out.println("û���ҵ�Ŀ�꣡"+solve.list.size());
		}
		s.lay();
	}	
	public void del(){
			System.out.println("��������Ҫɾ���û��ı��");
			String tmp="";
			tmp = cin.next();
			for(int i =0 ;i<solve.list.size();++ i){
				book t = (book)solve.list.get(i);
				if(t.getId().equals(tmp)){
					solve.list.remove(i);
					break;
				}
			}
			s.lay();
		}
}
